// #8 Add a string of data to the controller scope the the text "This is an expression".
app.controller("myCtrl", function($scope) {
  $scope.express = "This is an expression";

  // #14 Create an array of objects using Angular $scope.
  $scope.users = [
    {
      username: "chris",
      useremail: "chris@gmail.com"
    },
    {
      username: "matt",
      useremail: "matt@gmail.com"
    },
    {
      username: "sam",
      useremail: "sma@gmail.com"
    }
  ];
});
